# Introduction

This is TicketBooking backend project build on Node JS and MongoDB database Used  

## Run Project 

Download Project TicketBooking-Backend-Node

Go to project directory

and run

```bash
 npm install
```

it will take sometime to install the necessory files. 

after installation please run to

```bash
 npm start
```

this will run the server of the backend at 5000 port