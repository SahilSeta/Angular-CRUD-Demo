const CONNECTION_URL = 'mongodb://127.0.0.1:27017/shopbridge'
const PORT = process.env.PORT || 4500;

module.exports = {CONNECTION_URL,PORT}