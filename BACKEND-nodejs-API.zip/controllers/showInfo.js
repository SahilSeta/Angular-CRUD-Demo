const shows = require('../models/shows.js')

const newProduct = async (req,res) => {
    const data = req.body 
    try {
        const result = await shows.create(data)
        res.status(200).json({result})
    } catch (error) {   
        console.log(error)
        res.status(500).json({message:"Something Went Wrong"})
    }
}
const updateProduct = async (req,res) => {
    const data = req.body 
    const {id}   = req.params
    try {
        const result = await shows.findByIdAndUpdate(id, {...data, id }, { new:true })
        console.log("result", result)
        res.status(200).json({result})
    } catch (error) {   
        console.log(error)
        res.status(500).json({message:"Something Went Wrong"})
    }
}
const showData = async (req,res) => {
    try {
        const data = await shows.find({});
        if(data){
            res.status(200).json({data})
            
        }
        else {
            res.status(400).json({data})
        }
    } catch (error) {   
        res.status(500).json({message:"Something Went Wrong"})
    }
}
const deleteProduct = async(req,res) => {
    const {id}   = req.params

    console.log(id)

    const data = await shows.findOneAndDelete({_id : id});
    console.log(data)
    console.log('deleted successfully')

    res.json({message:"Product Deleted Successfully"})
}
const getSingleProductData = async (req,res) => {
    try {
        const {id} = req.params;
        console.log("THIS IS AN ID HERE =====", id)
        const data = await shows.findById(id);
        console.log(data)
        if(data){
            res.status(200).json({data})
        }
        else {
            res.status(400).json({data})
        }
    } catch (error) {   
        res.status(500).json({message:"Something Went Wrong"})
    }
    
    // console.log("this is req",req)
}
module.exports = {newProduct, updateProduct,showData, deleteProduct, getSingleProductData}