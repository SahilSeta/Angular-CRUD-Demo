const mongoose = require('mongoose')

const showSchema = mongoose.Schema({
    id:{type:String,require:true},
    name:{type:String,require:true},
    description:{type:String},
    price:{type:Number,require:true},
    inStock:{type:Boolean,require:true},
})

module.exports = mongoose.model('shows',showSchema)