const express = require('express')
const {newProduct, updateProduct, showData, deleteProduct, getSingleProductData} = require('../controllers/showInfo.js')

const router = express.Router()

router.get('/', showData)
router.post('/add', newProduct)
router.put('/update/:id', updateProduct)
router.delete('/deleteproduct/:id', deleteProduct )
router.get('/view/:id', getSingleProductData)

module.exports = router