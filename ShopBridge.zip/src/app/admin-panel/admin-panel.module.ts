import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ProductsComponent } from './products/products.component';
import { AddProductComponent } from './products/add-product/add-product.component';
import { RouterModule } from '@angular/router';



@NgModule({
  declarations: [
  ],
  imports: [
    CommonModule,
    RouterModule.forRoot([
      { path: 'admin/dashboard', component: DashboardComponent },
      { path: 'admin/products', component: ProductsComponent },
      { path: 'admin/products', children: [
        { path:'add', component:AddProductComponent },
        { path:'update/:productid', component:AddProductComponent },
      ]}
    ]),
  ]
})
export class AdminPanelModule { }
