import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonFunction } from 'src/app/common';
import { ProductService } from 'src/app/services/productservice.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  productForm: FormGroup;
  isEditing : boolean = false;
  editProductID : any;
  stockStatus : string = "true";
  validationMessages : any;
  formErrors : any = {
    name: '',
    description: '',
    price: '',
    instock: ''
  };
  constructor(private fb : FormBuilder, private act : ActivatedRoute, private productService : ProductService, private router : Router) {
    this.productForm = fb.group({
      name: [
        null,
        Validators.compose([
          Validators.required,
          Validators.maxLength(100),
        ]),
      ],
      description: [
        null,
        Validators.compose([Validators.required, Validators.maxLength(500)]),
      ],
      price: [
        null,
        Validators.compose([Validators.required, Validators.min(1)]),
      ],
      instock: [
        null,
        Validators.compose([Validators.required]),
      ]
    });
    this.validationMessages = {
      name: {
        required: `Please Enter Product Name`,
        maxLength: `Maximum 100 characters allowed.`
      },
      description: {
        required: `Please Enter Product description`,
        maxlength: `Maximum 500 characters allowed.`
      },
      price: {
        required: `Please Enter Product price`,
        min: `Minimum price should be 1.`

      },
      instock: {
        required: `Please provide Stock status`,
      }
    };
  }

  ngOnInit(): void {
    let pagedata = 'a';
    this.act.params.subscribe(parameter => {
      console.log(parameter.productid)
      this.editProductID = parameter.productid;
      if(this.editProductID != undefined){
        this.isEditing = true;
        this.getProductDetailsOnEdit();
      }else if (this.editProductID == undefined) {
        this.isEditing = false;
      }
      console.log("isEditing",this.isEditing)
    })
  }
  addProduct(formdata : any){
    //console.log(formdata)
    this._generateErrors();
    if(formdata.valid){
      if(this.isEditing == true && this.editProductID != undefined){
        //console.log("product edit")
        let data = {
          name: formdata.value.name,
          description : formdata.value.description,
          price : formdata.value.price,
          inStock : formdata.value.instock
        }
        //console.log("data",data)
        this.productService.updateProduct(this.editProductID,data).subscribe(
          (res) => {
            console.log(res);
            Swal.fire({
              icon: 'success',
              title: 'Product Updated !',
              showConfirmButton: false,
              timer: 1500
            })
            this.router.navigateByUrl(`/admin/products`);
          },
          (error) => {
            console.log(error)
            Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'Something went wrong!'
            })
          }
        );

      }else if (this.isEditing == false){
        //console.log("product add")
        let data = {
          name: formdata.value.name,
          description : formdata.value.description,
          price : formdata.value.price,
          inStock : formdata.value.instock
        }
        //console.log("data",data)
        this.productService.createProduct(data).subscribe(
          (res) => {
            //console.log(res);
            Swal.fire({
              icon: 'success',
              title: 'Product Added !',
              showConfirmButton: false,
              timer: 1500
            })
            this.router.navigateByUrl(`/admin/products`);
          },
          (error) => {
            //console.log(error)
            Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'Something went wrong!'
            })
          }
        );
      }

    }

  }
  getProductDetailsOnEdit(){
    console.log(this.editProductID)
    if(this.editProductID != undefined){

      this.productService.getProductById(this.editProductID).subscribe(
        (res) => {
          console.log(res);
          if(!this.isEmptyObject(res.data)){
            console.log("we have data")
            this.productForm.patchValue({
              'name': res.data.name,
              'description': res.data.description,
              'price': res.data.price,
              'instock': res.data.inStock,
            });
            this.stockStatus = res.data.inStock;
            console.log("stockStatus",this.stockStatus)
          }
        }
      );
    }
  }
  printData(){
    //console.log(this.stockStatus)
  }

  // general function to check the array
  isEmptyObject(obj:any) {
    return (obj && (Object.keys(obj).length === 0));
  }

  // ERROR GENERATIONS
  private _generateErrors() {
    // Check validation and set errors
    for (const field in this.formErrors) {
      if (this.formErrors.hasOwnProperty(field)) {
        // Set errors for fields not inside datesGroup
        // Clear previous error message (if any)
        this.formErrors[field] = '';
        CommonFunction._setErrMsgs(this.productForm.get(field), this.formErrors, field, this.validationMessages);
      }
    }
  }
}
