import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services/productservice.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  showLoader : boolean = false;
  products : any = {
    haveproducts : false,
    data : []
  }
  deleteId : string = '';

  constructor(private productsService : ProductService) {
    this.getProductDetails();
   }

  ngOnInit(): void {
  }

  getProductDetails(){
    //console.log("Get products data start");
    this.products.data = [];
    this.showLoader = true;
    this.productsService.getProduct().subscribe(
      (res) => {
        //console.log("api res",res);
        this.products.haveproducts = true;
        this.showLoader = false;
        this.products.data = res.data;
      }
    );
  }
  processDelete(id:any){
    //console.log("deleted id" + id );
    Swal.fire({
      showDenyButton: true,
      title: 'Are you sure want to delete product ?',
      denyButtonText: "No",
      confirmButtonColor: '#3698E5',
      confirmButtonText: `Yes`
    }).then((result: any) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        this.productsService.deleteProduct(id).subscribe(
          (res) => {
            //console.log("course deleted of id" + id );
            this.getProductDetails();
          },
          (error) => {
            //console.log(error);
          }
        );
      }
    })
  }
  resetDelete(){
    this.deleteId = '';
  }
}
