import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ShopBridge';
  constructor(private router : Router){

  }

  ngOnInit(){
    // CURRENTLY DIRECTLY NAGIVATED TO THE AUTH PAGE.
    //this.router.navigateByUrl('/auth/login');
    this.router.navigateByUrl(window.location.pathname);
  }
}
