import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AdminPanelModule } from './admin-panel/admin-panel.module';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthModule } from './auth/auth.module';
import { HeaderComponent } from './layouts/header/header.component';
import { NavbarComponent } from './layouts/navbar/navbar.component';
import { FooterComponent } from './layouts/footer/footer.component';
import { DashboardComponent } from './admin-panel/dashboard/dashboard.component';
import { ProductsComponent } from './admin-panel/products/products.component';
import { AddProductComponent } from './admin-panel/products/add-product/add-product.component';
import { ApiService } from './services/api-services.service';
import { ProductService } from './services/productservice.service';
import { HttpClientModule } from '@angular/common/http';
import { LoadingSpinnerComponent } from './layouts/loading-spinner/loading-spinner.component';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    NavbarComponent,
    FooterComponent,
    DashboardComponent,
    ProductsComponent,
    AddProductComponent,
    LoadingSpinnerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AuthModule,
    AdminPanelModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [
    ApiService,
    ProductService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
