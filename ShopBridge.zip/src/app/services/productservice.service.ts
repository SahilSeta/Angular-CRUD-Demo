import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ApiService } from './api-services.service';


@Injectable({
  providedIn: 'root'
})
export class ProductService {
  constructor(private apiService : ApiService) { }
  createProduct(data: any): Observable<any> {
    return this.apiService.post('/show/add', data )
    .pipe(
      map(response => {
        return response;
      })
    );
  }
  getProduct(): Observable<any> {
    return this.apiService.get('/show' )
    .pipe(
      map(response => {
        return response;
      })
    );
  }
  getProductById(productID: any): Observable<any> {
    return this.apiService.get(`/show/view/${productID}` )
    .pipe(
      map(response => {
        return response;
      })
    );
  }
  updateProduct(deleteid: any, data : any): Observable<any> {
    return this.apiService.put(`/show/update/${deleteid}`, data)
    .pipe(
      map(response => {
        return response;
      })
    );
  }
  deleteProduct(deleteid: any): Observable<any> {
    return this.apiService.delete(`/show/deleteproduct/${deleteid}`)
    .pipe(
      map(response => {
        return response;
      })
    );
  }
}
