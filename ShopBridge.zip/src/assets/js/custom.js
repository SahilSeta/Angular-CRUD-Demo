$(document).ready(function() {

    $('#CreateCourse,#NewAssessments,#LearningObjective,#addFolder,#AddSection').on('shown.bs.modal', function () {
        $(this).find("input:visible:first").focus();
    })  



    // $(window).on('shown.bs.modal', function() { 
    //     $(this).find("input:visible:first").focus();

    // });

   // resizeDiv();
    setTimeout(function() {
        $('.sm-scroll').slimScroll({
            width: '100%',
            distance: '10px',
            size: '4px',
        });

        $(document.body).on('click', '.sm-scroll', function() {
            $('.sm-scroll').slimScroll({
                width: '100%',
                distance: '10px',
                size: '4px',
            });
        });

    }, 10);

    // $('.selectpicker').selectpicker();

    $(".rightSideOpen").click(function(){
        $(".right-sidebar").addClass("openBar");
        // $(".no-assessment-box").addClass("openBar");
        // $(".right-open-section").addClass("openBar-new");
        // $(".current-switch-main").addClass("openBar-switch");

      });

      $(".rightSideClose").click(function(){
        $(".right-sidebar").removeClass("openBar");
        // $(".no-assessment-box").removeClass("openBar");
        // $(".right-open-section").removeClass("openBar-new");
        // $(".current-switch-main").removeClass("openBar-switch");
      });

      $(".sidebar-icon").click(function(){
        $(".sidebar").toggleClass("collapse-sidebar");
        $(".slidebar-top-logo").fadeToggle('5000');
        $(".main-section").toggleClass("collapse-sidebar");
        $(".header-main").toggleClass("collapse-sidebar");
        $(".footer-main").toggleClass("collapse-sidebar");

      });

      $(".sidebar-icon-sm").click(function(){
        $(".sidebar").toggleClass("openBar-rs");
      });

     $(".header-main .sidebar-icon-mobile").click(function(){
        $(".sidebar").addClass("openBar-mobile");
     });

     $(".sidebar .sidebar-icon-mobile").click(function(){
        $(".sidebar").removeClass("openBar-mobile");
     });

     $('.head-search-mobile').click(function(event){
        event.stopPropagation();
         $(".head-search-input").slideToggle("fast");
    });

    $(".head-search-input").on("click", function (event) {
        event.stopPropagation();
    });

    $('.head-noti').click(function(event){
        event.stopPropagation();
         $(".noti-box").fadeToggle('');
         $(this).toggleClass("show");
    });

    $(".noti-box").on("click", function (event) {
        event.stopPropagation();
    });   
});


$(document).on("click", function () {
    $(".noti-box").fadeOut();
});

if($(window).innerWidth() <= 760) {
    $(document).on("click", function () {
        $(".head-search-input").slideUp();
    });
}


// $('#course-tab-scroll').scrollTabs();



setTimeout(function resizeDiv() {
    vph = $(window).height();
    vcp = $(".sidebar-nav-scroll").height();
    vcr = $(".right-sidebar").height();
    vcsd = $(".right-sidebar-head").outerHeight();



    $('.sidebar-nav').css({ 'max-height': vcp + 'px' });
    $('.right-sidebar-results').css({ 'max-height': vcr - vcsd + 1 + 'px' });


     // vcp = $(".container-main").outerHeight();
     // vft = $(".footer-main").outerHeight();
     // $('.container-main').css({ 'min-height': vph - vft + 'px' });
 }, 100);
